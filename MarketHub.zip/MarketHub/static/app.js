document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.listing-card,.btn').forEach(el=>{el.addEventListener('pointerdown',()=>el.classList.add('pressed'));['pointerup','pointerleave','pointercancel'].forEach(e=>el.addEventListener(e,()=>el.classList.remove('pressed')))});const input=document.getElementById('image');if(input)input.addEventListener('change',()=>{const f=input.files&&input.files[0];document.getElementById('upload-title').textContent=f?'Image selected':'Choose an image to upload';document.getElementById('upload-name').textContent=f?f.name:'PNG, JPG, WEBP or GIF'});if('IntersectionObserver'in window){const o=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');o.unobserve(e.target)}}),{threshold:.08});document.querySelectorAll('.listing-card').forEach(c=>{c.classList.add('reveal');o.observe(c)})}});

/* Deliberate, low-motion navigation and first-visit slide intro */
(()=> {
 const loader=document.getElementById('intro-loader');
 const transition=document.getElementById('page-transition');
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const finish=()=>{if(loader)loader.classList.add('done');document.body.classList.add('page-ready');};
 let firstVisit=false;
 try{firstVisit=!sessionStorage.getItem('markethub-intro-seen');if(firstVisit)sessionStorage.setItem('markethub-intro-seen','1');}catch(e){firstVisit=true;}
 if(loader){
   if(reduced||!firstVisit){finish();}
   else window.setTimeout(finish,4500);
 }
 document.addEventListener('click',event=>{
   const a=event.target.closest('a[href]');
   if(!a||reduced||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||a.target||a.hasAttribute('download'))return;
   const url=new URL(a.href,location.href);
   if(url.origin!==location.origin||url.pathname===location.pathname&&url.search===location.search||a.href.includes('#'))return;
   if(transition){event.preventDefault();transition.classList.add('active');window.setTimeout(()=>location.href=a.href,230);}
 });
})();


/* Live unread badges and incoming-message updates (polling fallback; no websocket service required). */
(()=>{
 const badge=document.getElementById('nav-unread');
 const box=document.getElementById('message-list');
 const onThread=!!box;
 const currentUserId=Number(document.body.dataset.userId||0);
 let lastToastId=0;let previousUnread=null;
 function setBadge(n){if(!badge)return;const count=Number(n)||0;badge.textContent=count>99?'99+':String(count);badge.hidden=count<1;}
 function showMessageToast(m){if(onThread&&Number(m.sender_id)===currentUserId)return;let toast=document.getElementById('message-notice');if(!toast){toast=document.createElement('a');toast.id='message-notice';toast.className='message-notice';document.body.appendChild(toast);}toast.href='/messages/'+encodeURIComponent(m.sender_id);toast.replaceChildren();const title=document.createElement('b');title.textContent='New message from '+(m.username||'a member');const body=document.createElement('span');body.textContent=String(m.body||'').slice(0,100);toast.append(title,body);toast.classList.add('show');window.setTimeout(()=>toast.classList.remove('show'),6500);}
 async function refreshNotifications(){
   try{const res=await fetch('/messages/notifications',{headers:{'Accept':'application/json'},cache:'no-store'});if(!res.ok)return;const data=await res.json();setBadge(data.unread);if(previousUnread!==null&&Number(data.unread)>previousUnread&&data.latest&&Number(data.latest.id)!==lastToastId){lastToastId=Number(data.latest.id);showMessageToast(data.latest);}previousUnread=Number(data.unread);}
   catch(e){}
 }
 function addMessage(m){
   if(!box||document.querySelector('[data-message-id="'+m.id+'"]'))return;
   const empty=box.querySelector('.chat-empty');if(empty)empty.remove();
   const line=document.createElement('div');line.className='message-line '+(Number(m.sender_id)===currentUserId?'mine':'theirs');line.dataset.messageId=m.id;
   const bubble=document.createElement('div');bubble.className='bubble';bubble.append(document.createTextNode(m.body));
   const small=document.createElement('small');small.textContent=String(m.created_at||'').slice(0,16).replace('T',' ');bubble.appendChild(small);line.appendChild(bubble);box.appendChild(line);box.scrollTop=box.scrollHeight;
 }
 async function refreshThread(){
   if(!box)return;
   try{const peer=box.dataset.peerId;const after=Number(box.dataset.lastId||0);const res=await fetch('/messages/'+peer+'/updates?after='+after,{headers:{'Accept':'application/json'},cache:'no-store'});if(!res.ok)return;const data=await res.json();for(const m of data.messages||[]){addMessage(m);box.dataset.lastId=Math.max(Number(box.dataset.lastId||0),Number(m.id));}if((data.messages||[]).length)refreshNotifications();}
   catch(e){}
 }
 window.addEventListener('load',()=>{if(box)box.scrollTop=box.scrollHeight;refreshNotifications();if(box)refreshThread();});
 if(document.querySelector('.nav-unread'))window.setInterval(refreshNotifications,6000);
 if(onThread)window.setInterval(refreshThread,2500);
})();
