Place your website logo here and name it exactly: logo.png
Recommended: transparent PNG, square (512x512 or larger). The header, footer, and full-screen intro will automatically use this image. If logo.png is absent, the built-in M mark is shown instead.
