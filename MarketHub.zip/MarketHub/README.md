# MarketHub — Marketplace + Owner Control Center

A responsive Flask/SQLite marketplace with a refined dark interface, a 4.5-second slide-style first-visit intro, smooth page transitions, private buyer/seller messaging with live polling and unread notifications, listing safety guidance, a blue visual theme, and an owner-only moderation panel.

## Run on Windows

1. Install Python 3.11+.
2. Extract the ZIP to a folder.
3. Open Command Prompt in that folder and run:

```bat
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

4. Open http://127.0.0.1:5000

## Owner login

- Email: `haider109238hu@gmail.com`
- Username: `SHAHzaib_40`
- Password: `SHAHzaib_40`

The app creates this owner account automatically on first startup. The password is hashed in the database. **Before putting the website on the public internet, set a unique password and a strong `SECRET_KEY`** using environment variables. Example in Windows CMD:

```bat
set OWNER_PASSWORD=choose-a-long-unique-password
set SECRET_KEY=use-a-long-random-secret-value
python app.py
```

The environment values are used when the owner account is first created; if the database already exists, the configured owner password is updated at startup. Keep your database private and back it up.

## Website logo

Place your transparent logo image at `static/images/logo.png`. The header, footer, and full-screen loading intro use the same image automatically. Recommended format: transparent PNG, 512×512 or larger. If the file is missing, the built-in “M” fallback appears.

## Features

- Registration and login with password hashing
- Marketplace search, categories, sorting, featured listings, price display, and detail views
- Private buyer/seller direct-message inbox and conversation threads
- Unread-message badge in the navigation, incoming-message toast notifications, and automatic thread refresh every 2.5 seconds
- Trusted-middleman safety reminder on listing pages (verify identities independently)
- First-visit animated intro and gentle page transitions, with reduced-motion accessibility support
- Listing creation and image uploads (8 MB maximum)
- Seller tools: edit, bump, renew for 30 days, remove, restore
- Owner dashboard with listing/user statistics and listing search
- Owner-only controls to edit, bump, renew, feature/unfeature, delete, and restore any listing
- Owner account moderation: suspend/reactivate member accounts
- SQLite storage created automatically; existing database columns are migrated in place
- Health endpoint at `/health`

## Important limitations

This is a marketplace project inspired by common marketplace workflows, not a 100% PlayerUp clone. Direct messaging is implemented, but real payment processing, escrow, formal disputes, identity checks, realtime push notifications, and automated trust/safety systems are not implemented. The trusted-middleman reminder is guidance only; the site does not verify or endorse any middleman. Do not claim escrow protection or use this for high-risk transactions without proper engineering, legal review, and payment-provider integration. Add HTTPS, CSRF protection, rate limiting, secure deployment configuration, and backups before production use.
