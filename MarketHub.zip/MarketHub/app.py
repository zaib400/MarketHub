from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from pathlib import Path
from datetime import datetime, timedelta
import sqlite3, os, uuid, re

BASE = Path(__file__).resolve().parent
DB = BASE / 'marketplace.db'
UPLOADS = BASE / 'static' / 'uploads'
UPLOADS.mkdir(parents=True, exist_ok=True)
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'replace-this-secret-key-before-public-deployment')
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024
CATEGORIES = ['Gaming', 'Services', 'Digital Goods', 'Design', 'Development', 'Marketing', 'Other']
OWNER_EMAIL = os.environ.get('OWNER_EMAIL', 'haider109238hu@gmail.com').strip().lower()
OWNER_USERNAME = os.environ.get('OWNER_USERNAME', 'MarketHubOwner')
# Set OWNER_PASSWORD in your hosting environment; never use the username as the password.
OWNER_PASSWORD = os.environ.get('OWNER_PASSWORD', 'Change-this-owner-password-927!')

def now(): return datetime.utcnow().replace(microsecond=0)
def stamp(dt=None): return (dt or now()).isoformat(timespec='seconds')
def connect():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL, is_owner INTEGER NOT NULL DEFAULT 0, is_banned INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, price REAL NOT NULL, description TEXT NOT NULL, image TEXT, status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL, bumped_at TEXT, expires_at TEXT, views INTEGER NOT NULL DEFAULT 0, featured INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER NOT NULL, listing_id INTEGER NOT NULL, PRIMARY KEY(user_id, listing_id));
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, sender_id INTEGER NOT NULL, receiver_id INTEGER NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL, read_at TEXT, FOREIGN KEY(sender_id) REFERENCES users(id), FOREIGN KEY(receiver_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS support_tickets(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, subject TEXT NOT NULL, category TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS ticket_messages(id INTEGER PRIMARY KEY, ticket_id INTEGER NOT NULL, sender_id INTEGER NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(ticket_id) REFERENCES support_tickets(id), FOREIGN KEY(sender_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY, actor_id INTEGER, action TEXT NOT NULL, target TEXT NOT NULL DEFAULT '', details TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS user_roles(user_id INTEGER NOT NULL, role TEXT NOT NULL, granted_by INTEGER NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(user_id,role));
        ''')
        # Migrate an existing MarketHub database without deleting its data.
        for table, cols in {
            'users': {'is_owner': 'INTEGER NOT NULL DEFAULT 0', 'is_banned': 'INTEGER NOT NULL DEFAULT 0'},
            'listings': {'bumped_at': 'TEXT', 'expires_at': 'TEXT', 'views': 'INTEGER NOT NULL DEFAULT 0', 'featured': 'INTEGER NOT NULL DEFAULT 0'}
        }.items():
            existing = {r['name'] for r in c.execute(f'PRAGMA table_info({table})').fetchall()}
            for col, spec in cols.items():
                if col not in existing: c.execute(f'ALTER TABLE {table} ADD COLUMN {col} {spec}')
        owner = c.execute('SELECT id FROM users WHERE lower(email)=?', (OWNER_EMAIL,)).fetchone()
        if owner:
            c.execute('UPDATE users SET is_owner=1,password_hash=? WHERE id=?', (generate_password_hash(OWNER_PASSWORD), owner['id']))
        else:
            # Owner login can be changed safely through environment variables before deployment.
            c.execute('INSERT INTO users(username,email,password_hash,created_at,is_owner) VALUES(?,?,?,?,1)',
                      (OWNER_USERNAME, OWNER_EMAIL, generate_password_hash(OWNER_PASSWORD), stamp()))
        if c.execute('SELECT COUNT(*) FROM listings').fetchone()[0] == 0:
            c.execute('INSERT OR IGNORE INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)', ('market_demo','demo@invalid.local',generate_password_hash(uuid.uuid4().hex),stamp()))
            uid = c.execute('SELECT id FROM users WHERE username=?',('market_demo',)).fetchone()[0]
            samples = [
                ('Premium Gaming Account','Gaming',49.99,'A sample listing to demonstrate the marketplace. Check all details before buying.'),
                ('Discord Server Setup','Services',35.00,'Professional server structure, channels, roles, and polished embeds for your community.'),
                ('Website Starter Template','Digital Goods',19.00,'A clean starter template for a small business website.'),
                ('Logo & Brand Kit','Design',24.50,'A sample design service listing with a clear scope and delivery details.'),
                ('Python Bot Development','Development',60.00,'A demo service listing for a custom Python automation project.'),
                ('Community Promotion Pack','Marketing',15.00,'A sample promotion listing. Confirm the exact scope with the seller.')]
            c.executemany('INSERT INTO listings(user_id,title,category,price,description,created_at,bumped_at,expires_at) VALUES(?,?,?,?,?,?,?,?)',
                [(uid,*x,stamp(),stamp(),stamp(now()+timedelta(days=30))) for x in samples])
        c.execute("UPDATE listings SET bumped_at=COALESCE(bumped_at,created_at), expires_at=COALESCE(expires_at,?)", (stamp(now()+timedelta(days=30)),))

def user():
    uid = session.get('user_id')
    if not uid: return None
    with connect() as c: return c.execute('SELECT id,username,email,is_owner,is_banned FROM users WHERE id=?',(uid,)).fetchone()
def require_login():
    u=user()
    if not u: return None
    if u['is_banned']:
        session.clear(); return None
    return u
def owner_required():
    u=require_login()
    if not u: return redirect(url_for('login'))
    if not u['is_owner']: abort(403)
    return u
@app.context_processor
def common():
    u=user(); roles=[]
    if u:
        with connect() as c: roles=[r['role'] for r in c.execute('SELECT role FROM user_roles WHERE user_id=?',(u['id'],)).fetchall()]
    
    unread_count=0
    if u:
        with connect() as c: unread_count=c.execute('SELECT COUNT(*) FROM messages WHERE receiver_id=? AND read_at IS NULL',(u['id'],)).fetchone()[0]
    return {'current_user':u,'categories':['All']+CATEGORIES,'is_owner':bool(u and u['is_owner']),'current_roles':roles,'unread_count':unread_count}

def audit(actor_id, action, target='', details=''):
    with connect() as c: c.execute('INSERT INTO audit_logs(actor_id,action,target,details,created_at) VALUES(?,?,?,?,?)',(actor_id,action,str(target),str(details)[:1000],stamp()))


def save_image(file):
    if not file or not file.filename: return None, None
    allowed={'image/png':'png','image/jpeg':'jpg','image/webp':'webp','image/gif':'gif'}
    if file.mimetype not in allowed: return None, 'Image must be PNG, JPG, WEBP, or GIF.'
    name=uuid.uuid4().hex+'.'+allowed[file.mimetype]
    file.save(UPLOADS/name)
    return name, None

def listing_form_values():
    title=request.form.get('title','').strip(); cat=request.form.get('category','Other'); desc=request.form.get('description','').strip()
    try: price=float(request.form.get('price',''))
    except (ValueError, TypeError): price=-1
    if len(title)<4 or len(title)>90 or len(desc)<20 or len(desc)>5000 or price<0 or price>100000000 or cat not in CATEGORIES:
        return None, 'Check title, category, description (20–5000 characters), and price.'
    return {'title':title,'category':cat,'description':desc,'price':price},None

@app.route('/')
def index():
    q=request.args.get('q','').strip(); category=request.args.get('category','All'); sort=request.args.get('sort','newest')
    sql="SELECT l.*,u.username FROM listings l JOIN users u ON u.id=l.user_id WHERE l.status='active' AND u.is_banned=0 AND (l.expires_at IS NULL OR l.expires_at>?)"; args=[stamp()]
    if q: sql+=' AND (l.title LIKE ? OR l.description LIKE ? OR l.category LIKE ?)'; args += [f'%{q}%']*3
    if category in CATEGORIES: sql+=' AND l.category=?'; args.append(category)
    order={'price_low':'l.price ASC','price_high':'l.price DESC','oldest':'l.id ASC','popular':'l.views DESC'}.get(sort,"COALESCE(l.bumped_at,l.created_at) DESC")
    sql+=' ORDER BY l.featured DESC, '+order
    with connect() as c:
        listings=c.execute(sql,args).fetchall()
        stats={'listings':c.execute("SELECT COUNT(*) FROM listings WHERE status='active' AND (expires_at IS NULL OR expires_at>?)",(stamp(),)).fetchone()[0], 'sellers':c.execute('SELECT COUNT(*) FROM users WHERE is_banned=0 AND is_owner=0').fetchone()[0], 'categories':c.execute("SELECT COUNT(DISTINCT category) FROM listings WHERE status='active' AND (expires_at IS NULL OR expires_at>?)",(stamp(),)).fetchone()[0]}
    return render_template('index.html',listings=listings,q=q,category=category,sort=sort,stats=stats)

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        name=request.form.get('username','').strip(); email=request.form.get('email','').strip().lower(); pw=request.form.get('password','')
        if not re.fullmatch(r'[A-Za-z0-9_]{3,24}',name): flash('Username must be 3–24 letters, numbers, or underscores.','error')
        elif '@' not in email or len(pw)<8: flash('Enter a valid email and a password with at least 8 characters.','error')
        else:
            try:
                with connect() as c: cur=c.execute('INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)',(name,email,generate_password_hash(pw),stamp())); session['user_id']=cur.lastrowid
                flash('Account created. Welcome!','success'); return redirect(url_for('index'))
            except sqlite3.IntegrityError: flash('That username or email is already registered.','error')
    return render_template('auth.html',mode='register')

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        ident=request.form.get('identity','').strip(); password=request.form.get('password','')
        with connect() as c: u=c.execute('SELECT * FROM users WHERE username=? OR lower(email)=?',(ident,ident.lower())).fetchone()
        if u and check_password_hash(u['password_hash'],password) and not u['is_banned']:
            session.clear(); session['user_id']=u['id']; flash('Welcome to your owner dashboard.' if u['is_owner'] else 'You are signed in.','success')
            return redirect(url_for('owner_dashboard') if u['is_owner'] else url_for('index'))
        flash('Incorrect username/email or password.','error')
    return render_template('auth.html',mode='login')
@app.route('/logout',methods=['POST','GET'])
def logout(): session.clear(); flash('Signed out.','success'); return redirect(url_for('index'))

@app.route('/listing/new',methods=['GET','POST'])
def new_listing():
    u=require_login()
    if not u: flash('Sign in to publish a listing.','error'); return redirect(url_for('login'))
    if request.method=='POST':
        data,error=listing_form_values()
        if error: flash(error,'error')
        else:
            image,error=save_image(request.files.get('image'))
            if error: flash(error,'error')
            else:
                with connect() as c: c.execute('INSERT INTO listings(user_id,title,category,price,description,image,created_at,bumped_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)',(u['id'],data['title'],data['category'],data['price'],data['description'],image,stamp(),stamp(),stamp(now()+timedelta(days=30))))
                audit(u['id'],'listing_created',data['title'],f'Price: {data["price"]}')
                flash('Listing published for 30 days.','success'); return redirect(url_for('index'))
    return render_template('new_listing.html')

@app.route('/listing/<int:lid>')
def detail(lid):
    with connect() as c:
        item=c.execute("SELECT l.*,u.username FROM listings l JOIN users u ON u.id=l.user_id WHERE l.id=? AND l.status='active' AND u.is_banned=0",(lid,)).fetchone()
        if item: c.execute('UPDATE listings SET views=views+1 WHERE id=?',(lid,))
    if not item: abort(404)
    u=user(); saved=False
    if u:
        with connect() as c: saved=bool(c.execute('SELECT 1 FROM favorites WHERE user_id=? AND listing_id=?',(u['id'],lid)).fetchone())
    return render_template('detail.html',item=item,saved=saved)

@app.route('/listing/<int:lid>/favorite',methods=['POST'])
def favorite(lid):
    u=require_login()
    if not u: flash('Sign in to save favorites.','error'); return redirect(url_for('login'))
    with connect() as c:
        if not c.execute("SELECT 1 FROM listings WHERE id=? AND status='active'",(lid,)).fetchone(): abort(404)
        if c.execute('SELECT 1 FROM favorites WHERE user_id=? AND listing_id=?',(u['id'],lid)).fetchone(): c.execute('DELETE FROM favorites WHERE user_id=? AND listing_id=?',(u['id'],lid))
        else: c.execute('INSERT OR IGNORE INTO favorites(user_id,listing_id) VALUES(?,?)',(u['id'],lid))
    return redirect(url_for('detail',lid=lid))

@app.route('/my-listings')
def mine():
    u=require_login()
    if not u: return redirect(url_for('login'))
    with connect() as c: items=c.execute('SELECT * FROM listings WHERE user_id=? ORDER BY id DESC',(u['id'],)).fetchall()
    return render_template('mine.html',listings=items)

def can_manage_listing(u,item):
    if not item: abort(404)
    if not u or (item['user_id']!=u['id'] and not u['is_owner']): abort(403)

@app.route('/listing/<int:lid>/edit',methods=['GET','POST'])
def edit_listing(lid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    with connect() as c: item=c.execute('SELECT * FROM listings WHERE id=?',(lid,)).fetchone()
    can_manage_listing(u,item)
    if request.method=='POST':
        data,error=listing_form_values()
        if error: flash(error,'error')
        else:
            image,error=save_image(request.files.get('image'))
            if error: flash(error,'error')
            else:
                with connect() as c:
                    if image: c.execute('UPDATE listings SET title=?,category=?,price=?,description=?,image=? WHERE id=?',(data['title'],data['category'],data['price'],data['description'],image,lid))
                    else: c.execute('UPDATE listings SET title=?,category=?,price=?,description=? WHERE id=?',(data['title'],data['category'],data['price'],data['description'],lid))
                flash('Listing updated.','success'); return redirect(url_for('owner_dashboard') if u['is_owner'] else url_for('mine'))
    return render_template('new_listing.html',item=item,edit_mode=True)

@app.route('/listing/<int:lid>/delete',methods=['POST'])
def delete(lid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    with connect() as c:
        item=c.execute('SELECT * FROM listings WHERE id=?',(lid,)).fetchone(); can_manage_listing(u,item)
        c.execute("UPDATE listings SET status='deleted' WHERE id=?",(lid,))
    flash('Listing removed.','success'); return redirect(url_for('owner_dashboard') if u['is_owner'] else url_for('mine'))

@app.route('/listing/<int:lid>/restore',methods=['POST'])
def restore_listing(lid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    with connect() as c:
        item=c.execute('SELECT * FROM listings WHERE id=?',(lid,)).fetchone(); can_manage_listing(u,item)
        c.execute("UPDATE listings SET status='active',expires_at=?,bumped_at=? WHERE id=?",(stamp(now()+timedelta(days=30)),stamp(),lid))
    flash('Listing restored for 30 days.','success'); return redirect(url_for('owner_dashboard') if u['is_owner'] else url_for('mine'))

@app.route('/listing/<int:lid>/bump',methods=['POST'])
def bump_listing(lid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    with connect() as c:
        item=c.execute('SELECT * FROM listings WHERE id=?',(lid,)).fetchone(); can_manage_listing(u,item)
        if item['status']!='active': flash('Restore this listing before bumping it.','error')
        else:
            last=item['bumped_at'] or item['created_at']
            try: next_bump=datetime.fromisoformat(last)+timedelta(hours=10)
            except (TypeError,ValueError): next_bump=now()
            if now()<next_bump:
                remaining=next_bump-now(); hours=max(0,remaining.seconds//3600 + (1 if remaining.seconds%3600 else 0))
                flash(f'This listing can be bumped again in about {hours} hour(s). Each listing has a 10-hour cooldown.','error')
            else:
                c.execute('UPDATE listings SET bumped_at=? WHERE id=?',(stamp(),lid)); flash('Listing bumped to the top. You can bump this listing again in 10 hours.','success')
    return redirect(url_for('owner_dashboard') if u['is_owner'] else url_for('mine'))

@app.route('/listing/<int:lid>/renew',methods=['POST'])
def renew_listing(lid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    with connect() as c:
        item=c.execute('SELECT * FROM listings WHERE id=?',(lid,)).fetchone(); can_manage_listing(u,item)
        base=now()
        if item['expires_at']:
            try: base=max(base,datetime.fromisoformat(item['expires_at']))
            except ValueError: pass
        c.execute("UPDATE listings SET status='active',expires_at=?,bumped_at=? WHERE id=?",(stamp(base+timedelta(days=30)),stamp(),lid))
    flash('Listing renewed for another 30 days.','success'); return redirect(url_for('owner_dashboard') if u['is_owner'] else url_for('mine'))

@app.route('/owner')
def owner_dashboard():
    u=require_login()
    if not u: return redirect(url_for('login'))
    if not u['is_owner']: abort(403)
    q=request.args.get('q','').strip(); status=request.args.get('status','all'); ticket_q=request.args.get('ticket_q','').strip(); ticket_status=request.args.get('ticket_status','all')
    sql='SELECT l.*,u.username,u.email FROM listings l JOIN users u ON u.id=l.user_id WHERE 1=1'; args=[]
    if q: sql+=' AND (l.title LIKE ? OR u.username LIKE ? OR u.email LIKE ? OR CAST(l.id AS TEXT)=?)'; args += [f'%{q}%']*3+[q.lstrip('#')]
    if status in ('active','deleted'): sql+=' AND l.status=?'; args.append(status)
    sql+=' ORDER BY l.id DESC LIMIT 250'
    with connect() as c:
        listings=c.execute(sql,args).fetchall()
        stats={'listings':c.execute('SELECT COUNT(*) FROM listings').fetchone()[0], 'active':c.execute("SELECT COUNT(*) FROM listings WHERE status='active'").fetchone()[0], 'users':c.execute('SELECT COUNT(*) FROM users WHERE is_owner=0').fetchone()[0], 'views':c.execute('SELECT COALESCE(SUM(views),0) FROM listings').fetchone()[0], 'deleted':c.execute("SELECT COUNT(*) FROM listings WHERE status='deleted'").fetchone()[0]}
        users=c.execute("SELECT id,username,email,created_at,is_banned FROM users WHERE is_owner=0 AND (? = '' OR username LIKE ? OR email LIKE ?) ORDER BY id DESC LIMIT 250",(q,f'%{q}%',f'%{q}%')).fetchall()
        ticket_sql="SELECT t.*,COALESCE(u.username,'Deleted account') AS username FROM support_tickets t LEFT JOIN users u ON u.id=t.user_id WHERE 1=1"; ticket_args=[]
        if ticket_q:
            ticket_sql += " AND (t.subject LIKE ? OR COALESCE(u.username,'') LIKE ? OR CAST(t.id AS TEXT)=?)"; ticket_args += [f'%{ticket_q}%',f'%{ticket_q}%',ticket_q.lstrip('#')]
        if ticket_status in ('open','closed'):
            ticket_sql += ' AND t.status=?'; ticket_args.append(ticket_status)
        ticket_sql += " ORDER BY CASE t.status WHEN 'open' THEN 0 ELSE 1 END,t.updated_at DESC LIMIT 1000"
        tickets=c.execute(ticket_sql,ticket_args).fetchall()
        logs=c.execute('SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 200').fetchall()
    return render_template('owner.html',listings=listings,users=users,stats=stats,q=q,status=status,tickets=tickets,logs=logs,ticket_q=ticket_q,ticket_status=ticket_status)

@app.route('/owner/listing/<int:lid>/feature',methods=['POST'])
def owner_feature(lid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    if not u['is_owner']: abort(403)
    with connect() as c:
        item=c.execute('SELECT featured FROM listings WHERE id=?',(lid,)).fetchone()
        if not item: abort(404)
        c.execute('UPDATE listings SET featured=? WHERE id=?',(0 if item['featured'] else 1,lid))
    flash('Listing removed from featured.' if item['featured'] else 'Listing featured on the marketplace.','success')
    return redirect(url_for('owner_dashboard'))

@app.route('/owner/user/<int:uid>/ban',methods=['POST'])
def owner_toggle_ban(uid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    if not u['is_owner']: abort(403)
    with connect() as c:
        target=c.execute('SELECT id,is_owner,is_banned FROM users WHERE id=?',(uid,)).fetchone()
        if not target or target['is_owner']: abort(403)
        c.execute('UPDATE users SET is_banned=? WHERE id=?',(0 if target['is_banned'] else 1,uid))
    audit(u['id'],'account_suspended' if not target['is_banned'] else 'account_reactivated',uid)
    flash('Account suspended.' if not target['is_banned'] else 'Account reactivated.','success')
    return redirect(url_for('owner_dashboard')+'#users')


@app.route('/messages')
def messages():
    u=require_login()
    if not u:
        flash('Sign in to use private messages.','error')
        return redirect(url_for('login'))
    with connect() as c:
        rows=c.execute("""SELECT peer.id, peer.username, m.body AS last_body, m.created_at AS last_at,
            (SELECT COUNT(*) FROM messages unread WHERE unread.sender_id=peer.id AND unread.receiver_id=? AND unread.read_at IS NULL) AS unread
            FROM users peer JOIN messages m ON m.id=(
              SELECT MAX(mm.id) FROM messages mm WHERE
              (mm.sender_id=? AND mm.receiver_id=peer.id) OR (mm.sender_id=peer.id AND mm.receiver_id=?))
            WHERE peer.id != ? ORDER BY m.id DESC""",(u['id'],u['id'],u['id'],u['id'])).fetchall()
    return render_template('messages.html', conversations=rows)

@app.route('/messages/<int:peer_id>', methods=['GET','POST'])
def message_thread(peer_id):
    u=require_login()
    if not u:
        flash('Sign in to message a seller.','error')
        return redirect(url_for('login'))
    if peer_id == u['id']:
        flash('You cannot start a conversation with your own account.','error')
        return redirect(url_for('messages'))
    with connect() as c:
        peer=c.execute('SELECT id,username,created_at FROM users WHERE id=? AND is_banned=0',(peer_id,)).fetchone()
        if not peer: abort(404)
        if request.method=='POST':
            body=request.form.get('body','').strip()
            if not body or len(body)>2000:
                flash('Messages must contain 1–2,000 characters.','error')
            else:
                c.execute('INSERT INTO messages(sender_id,receiver_id,body,created_at) VALUES(?,?,?,?)',(u['id'],peer_id,body,stamp()))
                return redirect(url_for('message_thread',peer_id=peer_id))
        c.execute('UPDATE messages SET read_at=? WHERE sender_id=? AND receiver_id=? AND read_at IS NULL',(stamp(),peer_id,u['id']))
        thread=c.execute("""SELECT m.*, s.username AS sender_name FROM messages m JOIN users s ON s.id=m.sender_id
            WHERE (m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?)
            ORDER BY m.id ASC LIMIT 500""",(u['id'],peer_id,peer_id,u['id'])).fetchall()
    return render_template('thread.html',peer=peer,thread=thread)

@app.route('/messages/notifications')
def message_notifications():
    u=require_login()
    if not u: return {'unread': 0, 'latest': None}, 401
    with connect() as c:
        count=c.execute('SELECT COUNT(*) FROM messages WHERE receiver_id=? AND read_at IS NULL',(u['id'],)).fetchone()[0]
        latest=c.execute("SELECT m.id,m.sender_id,m.body,m.created_at,u.username FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.receiver_id=? AND m.read_at IS NULL ORDER BY m.id DESC LIMIT 1",(u['id'],)).fetchone()
    return {'unread':count,'latest':dict(latest) if latest else None}

@app.route('/messages/<int:peer_id>/updates')
def message_updates(peer_id):
    u=require_login()
    if not u: return {'messages': []}, 401
    if peer_id == u['id']: return {'messages': []}, 400
    try: after=max(0,int(request.args.get('after','0')))
    except (ValueError,TypeError): after=0
    with connect() as c:
        peer=c.execute('SELECT id FROM users WHERE id=? AND is_banned=0',(peer_id,)).fetchone()
        if not peer: return {'messages': []}, 404
        rows=c.execute("SELECT m.id,m.sender_id,m.receiver_id,m.body,m.created_at,u.username AS sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id>? AND ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?)) ORDER BY m.id ASC LIMIT 100",(after,u['id'],peer_id,peer_id,u['id'])).fetchall()
        c.execute('UPDATE messages SET read_at=? WHERE sender_id=? AND receiver_id=? AND read_at IS NULL',(stamp(),peer_id,u['id']))
    return {'messages':[dict(row) for row in rows]}

@app.route('/support', methods=['GET','POST'])
def support():
    u=require_login()
    if not u:
        flash('Sign in to contact support.','error'); return redirect(url_for('login'))
    if request.method=='POST':
        subject=request.form.get('subject','').strip(); category=request.form.get('category','General'); body=request.form.get('body','').strip()
        if len(subject)<4 or len(subject)>120 or len(body)<10 or len(body)>4000 or category not in ('General','Account','Listing','Scam report','Trade safety','Other'):
            flash('Please provide a valid subject and message.','error')
        else:
            with connect() as c:
                cur=c.execute('INSERT INTO support_tickets(user_id,subject,category,created_at,updated_at) VALUES(?,?,?,?,?)',(u['id'],subject,category,stamp(),stamp()))
                tid=cur.lastrowid
                c.execute('INSERT INTO ticket_messages(ticket_id,sender_id,body,created_at) VALUES(?,?,?,?)',(tid,u['id'],body,stamp()))
            try:
                audit(u['id'],'support_ticket_opened',tid,subject)
            except sqlite3.Error:
                app.logger.exception('Could not record ticket creation audit event for ticket %s', tid)
            return redirect(url_for('ticket_view',tid=tid))
    with connect() as c: tickets=c.execute('SELECT * FROM support_tickets WHERE user_id=? ORDER BY updated_at DESC',(u['id'],)).fetchall()
    return render_template('support.html',tickets=tickets)

@app.route('/support/<int:tid>', methods=['GET', 'POST'])
def ticket_view(tid):
    u = require_login()
    if not u:
        return redirect(url_for('login'))

    if request.method == 'POST':
        body = request.form.get('body', '').strip()
        if not body or len(body) > 4000:
            flash('Enter a message of up to 4,000 characters.', 'error')
            return redirect(url_for('ticket_view', tid=tid))

        with connect() as c:
            ticket = c.execute(
                'SELECT id, user_id, status FROM support_tickets WHERE id=?', (tid,)
            ).fetchone()
            if not ticket:
                abort(404)
            if not u['is_owner'] and ticket['user_id'] != u['id']:
                abort(403)
            if ticket['status'] == 'closed' and not u['is_owner']:
                flash('This ticket is closed. Open a new ticket if you need more help.', 'error')
                return redirect(url_for('ticket_view', tid=tid))
            c.execute(
                'INSERT INTO ticket_messages(ticket_id,sender_id,body,created_at) VALUES(?,?,?,?)',
                (tid, u['id'], body, stamp())
            )
            c.execute(
                'UPDATE support_tickets SET updated_at=?, status=? WHERE id=?',
                (stamp(), 'open' if u['is_owner'] else ticket['status'], tid)
            )
        try:
            audit(u['id'], 'support_reply', tid, body[:100])
        except sqlite3.Error:
            app.logger.exception('Could not record support reply audit event for ticket %s', tid)
        return redirect(url_for('ticket_view', tid=tid))

    with connect() as c:
        ticket = c.execute(
            "SELECT t.*, COALESCE(u.username,'Deleted account') AS username FROM support_tickets t LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?",
            (tid,)
        ).fetchone()
        if not ticket:
            abort(404)
        if not u['is_owner'] and ticket['user_id'] != u['id']:
            abort(403)
        msgs = c.execute(
            "SELECT m.*, COALESCE(u.username,'Deleted account') AS username FROM ticket_messages m LEFT JOIN users u ON u.id=m.sender_id WHERE m.ticket_id=? ORDER BY m.id",
            (tid,)
        ).fetchall()
    return render_template('ticket.html', ticket=ticket, thread=msgs)

@app.route('/owner/user/<int:uid>/role',methods=['POST'])
def owner_role(uid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    if not u['is_owner']: abort(403)
    role=request.form.get('role','trusted')
    if role not in ('trusted',''): abort(400)
    with connect() as c:
        target=c.execute('SELECT id,is_owner FROM users WHERE id=?',(uid,)).fetchone()
        if not target or target['is_owner']: abort(404)
        if role: c.execute('INSERT OR IGNORE INTO user_roles(user_id,role,granted_by,created_at) VALUES(?,?,?,?)',(uid,role,u['id'],stamp()))
        else: c.execute("DELETE FROM user_roles WHERE user_id=? AND role='trusted'",(uid,))
    audit(u['id'],'role_granted' if role else 'role_removed',uid,role or 'trusted')
    flash('Trusted role updated.','success'); return redirect(url_for('owner_dashboard')+'#users')

@app.route('/owner/ticket/<int:tid>/status',methods=['POST'])
def owner_ticket_status(tid):
    u=require_login()
    if not u: return redirect(url_for('login'))
    if not u['is_owner']: abort(403)
    status=request.form.get('status','closed')
    if status not in ('open','closed'): abort(400)
    with connect() as c:
        cur=c.execute('UPDATE support_tickets SET status=?,updated_at=? WHERE id=?',(status,stamp(),tid))
        if not cur.rowcount: abort(404)
    audit(u['id'],'ticket_'+status,tid)
    flash('Ticket '+status+'.','success')
    return redirect(url_for('owner_dashboard')+'#tickets')

@app.route('/health')
def health(): return {'ok':True,'app':'MarketHub'}
@app.errorhandler(400)
def bad_request(e): return render_template('error.html',code=400,message='That request could not be processed. Return to the site and try again. If it keeps happening, open a support ticket.'),400
@app.errorhandler(404)
def not_found(e): return render_template('error.html',code=404,message='That page or listing could not be found.'),404
@app.errorhandler(403)
def forbidden(e): return render_template('error.html',code=403,message='You do not have permission to do that.'),403
@app.errorhandler(413)
def too_large(e): return render_template('error.html',code=413,message='Image uploads must be smaller than 8 MB.'),413

init_db()
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=False)
